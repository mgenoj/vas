import pandas as pd
from datetime import datetime

# Define the data
data = {
    "ID": [1, 2, 3],
    "Title": [
        "Introduction to Artificial Intelligence",
        "Advanced Python Programming",
        "Docker Essentials for Developers"
    ],
    "Description": [
        "Artificial Intelligence (AI) is a branch of computer science that aims to create machines capable of intelligent behavior. "
        "It encompasses a variety of subfields, including machine learning, natural language processing, robotics, and computer vision. "
        "AI has applications across numerous industries, revolutionizing the way we interact with technology and automating complex tasks. "
        "From virtual assistants to autonomous vehicles, AI continues to evolve, offering both opportunities and challenges in the quest for smarter systems.",

        "Advanced Python Programming delves deeper into the versatile Python language, exploring its advanced features and libraries. "
        "This course covers topics such as decorators, generators, context managers, and metaprogramming. "
        "Participants will also learn about efficient data handling with libraries like Pandas and NumPy, as well as asynchronous programming with asyncio. "
        "By the end of the course, attendees will have a comprehensive understanding of Python's capabilities, enabling them to build robust and scalable applications.",

        "Docker Essentials for Developers introduces the foundational concepts of Docker and containerization. "
        "This course covers the installation and setup of Docker, creating and managing containers, and building custom Docker images using Dockerfiles. "
        "Participants will learn how to orchestrate multi-container applications with Docker Compose and understand best practices for container security and networking. "
        "Hands-on exercises will reinforce the skills needed to integrate Docker into the development workflow, enhancing deployment efficiency and consistency."
    ],
    "Category": ["Technology", "Education", "DevOps"],
    "Date Added": [
        datetime(2025, 1, 1),
        datetime(2025, 2, 15),
        datetime(2025, 3, 10)
    ],
    "Author": ["Jane Doe", "John Smith", "Emily Johnson"]
}

# Create a DataFrame
df = pd.DataFrame(data)

# Specify the order of columns
columns_order = ["ID", "Title", "Description", "Category", "Date Added", "Author"]

# Reorder the DataFrame columns
df = df[columns_order]

# Define the Excel file path
excel_file_path = "sample_data.xlsx"

# Write the DataFrame to an Excel file
df.to_excel(excel_file_path, index=False, engine='openpyxl')

print(f"Excel file '{excel_file_path}' has been created successfully.")
pip install pandas openpyxl
