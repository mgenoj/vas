import os
import pandas as pd
import openai
from fastapi import FastAPI, HTTPException, BackgroundTasks
from pydantic import BaseModel
from sqlalchemy import create_engine, Column, Integer, Text
from sqlalchemy.orm import sessionmaker, declarative_base
from pgvector.sqlalchemy import Vector
from dotenv import load_dotenv
import asyncio
import logging
from logging.handlers import RotatingFileHandler

# Load environment variables from .env file
load_dotenv()

# Configuration
DATABASE_URL = f"postgresql://{os.getenv('POSTGRES_USER')}:{os.getenv('POSTGRES_PASSWORD')}@db:5432/{os.getenv('POSTGRES_DB')}"
EXCEL_FILE_PATH = os.getenv('EXCEL_FILE_PATH')
OPENAI_API_KEY = os.getenv('OPENAI_API_KEY')
EMBEDDING_DIMENSION = 1536  # Adjust based on your embedding model

# Initialize OpenAI API key
openai.api_key = OPENAI_API_KEY

# Initialize SQLAlchemy base and session
Base = declarative_base()

class Document(Base):
    __tablename__ = 'documents'
    id = Column(Integer, primary_key=True, index=True)
    content = Column(Text, nullable=False)
    embedding = Column(Vector(EMBEDDING_DIMENSION), nullable=False)

# Create SQLAlchemy engine and session
engine = create_engine(DATABASE_URL)
SessionLocal = sessionmaker(autocommit=False, autoflush=False, bind=engine)

# Function to initialize the database and create tables
def init_db():
    try:
        with engine.connect() as conn:
            conn.execute("CREATE EXTENSION IF NOT EXISTS vector;")
        Base.metadata.create_all(bind=engine)
        logging.info("Database initialized successfully.")
    except Exception as e:
        logging.error(f"Error initializing database: {e}")

# Function to set up logging
def setup_logging():
    log_dir = os.getenv('LOG_DIR', '/var/log/app')  # Default to /var/log/app if LOG_DIR not set
    log_file = os.path.join(log_dir, 'app.log')

    if not os.path.exists(log_dir):
        os.makedirs(log_dir, exist_ok=True)

    logger = logging.getLogger()
    logger.setLevel(logging.INFO)

    # Console Handler
    console_handler = logging.StreamHandler()
    console_handler.setLevel(logging.INFO)
    console_formatter = logging.Formatter('%(asctime)s - %(levelname)s - %(message)s')
    console_handler.setFormatter(console_formatter)

    # File Handler with rotation
    file_handler = RotatingFileHandler(log_file, maxBytes=10*1024*1024, backupCount=5)  # 10MB per file, keep 5 backups
    file_handler.setLevel(logging.INFO)
    file_formatter = logging.Formatter('%(asctime)s - %(levelname)s - %(message)s')
    file_handler.setFormatter(file_formatter)

    logger.addHandler(console_handler)
    logger.addHandler(file_handler)

# Set up logging and initialize the database
setup_logging()
init_db()

# Initialize FastAPI app
app = FastAPI(title="Excel to PGVector API with Async and External Logging")

# Pydantic models for request and response
class SearchRequest(BaseModel):
    query: str
    top_k: int = 5

class SearchResponse(BaseModel):
    id: int
    content: str
    score: float

# Asynchronous function to generate embeddings
async def generate_embedding_async(text: str):
    """Asynchronously generate embedding for a given text."""
    try:
        loop = asyncio.get_event_loop()
        response = await loop.run_in_executor(
            None,
            lambda: openai.Embedding.create(
                input=text,
                model="text-embedding-ada-002"
            )
        )
        embedding = response['data'][0]['embedding']
        return embedding
    except Exception as e:
        logging.error(f"Error generating embedding: {e}")
        return None

# Function to read Excel file
def read_excel(file_path: str):
    """Read Excel file into a pandas DataFrame."""
    try:
        df = pd.read_excel(file_path)
        logging.info(f"Excel file '{file_path}' read successfully with {len(df)} rows.")
        return df
    except Exception as e:
        logging.error(f"Error reading Excel file: {e}")
        return None

# Asynchronous function to process and insert documents
async def process_and_insert_documents(df: pd.DataFrame):
    """Process each row in the DataFrame, generate embeddings, and insert into the database."""
    session = SessionLocal()
    try:
        tasks = []
        for index, row in df.iterrows():
            content = row.to_json()  # Convert the entire row to JSON string
            tasks.append(process_single_document(session, content))
        
        # Run all embedding generation tasks concurrently
        await asyncio.gather(*tasks)
        session.commit()
        logging.info("All documents processed and inserted successfully.")
    except Exception as e:
        session.rollback()
        logging.error(f"Error inserting documents: {e}")
    finally:
        session.close()

# Asynchronous function to process a single document
async def process_single_document(session, content: str):
    """Generate embedding for a single document and insert into the database."""
    embedding = await generate_embedding_async(content)
    if embedding:
        try:
            doc = Document(content=content, embedding=embedding)
            session.add(doc)
            logging.debug(f"Document added: {content[:50]}...")  # Log first 50 chars
        except Exception as e:
            logging.error(f"Error adding document to session: {e}")

# Startup event to process Excel file in the background
@app.on_event("startup")
async def startup_event():
    """On startup, read the Excel file and process documents in the background."""
    logging.info("Startup event triggered. Processing Excel file.")
    df = read_excel(EXCEL_FILE_PATH)
    if df is not None:
        # Use FastAPI's background tasks to process without blocking
        background_tasks = BackgroundTasks()
        background_tasks.add_task(process_and_insert_documents, df)
        await background_tasks()
    else:
        logging.error("Failed to read Excel file during startup.")

# API endpoint for semantic search
@app.post("/search", response_model=list[SearchResponse])
async def search_documents(request: SearchRequest):
    """Search documents based on semantic similarity to the query."""
    session = SessionLocal()
    try:
        # Generate embedding for the query
        query_embedding = await generate_embedding_async(request.query)
        if not query_embedding:
            raise HTTPException(status_code=500, detail="Failed to generate embedding for the query.")
        
        # Perform similarity search
        sql = """
        SELECT id, content, 1 - (embedding <-> :query_embedding) AS score
        FROM documents
        ORDER BY embedding <-> :query_embedding
        LIMIT :top_k;
        """
        result = session.execute(sql, {'query_embedding': query_embedding, 'top_k': request.top_k})
        documents = []
        for row in result:
            documents.append(SearchResponse(id=row.id, content=row.content, score=row.score))
        logging.info(f"Search completed for query: '{request.query}' with top_k={request.top_k}")
        return documents
    except Exception as e:
        logging.error(f"Search error: {e}")
        raise HTTPException(status_code=500, detail="Search operation failed.")
    finally:
        session.close()
